var userId = 'aedeb2f4-a458-465d-90b7-f04357a6bca4' || null;
            window.hj('identify', userId, {
                'Is New Rosebud User (joined < 48h)': false,
                'Firebase Id': 'yMUWZ4oF35YZ4hDVqfRl4snPWvq2',
            });